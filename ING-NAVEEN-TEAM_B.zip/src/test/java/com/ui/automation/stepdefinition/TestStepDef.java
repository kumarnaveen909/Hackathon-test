package com.ui.automation.stepdefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class TestStepDef {


@Given("Launch the application URL")
public void launch_the_application_URL() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@When("Mouse over for selecting All Categories link")
public void mouse_over_for_selecting_All_Categories_link() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@When("Select Offers link")
public void select_Offers_link() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@When("Select Health and Safety")
public void select_Health_and_Safety() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@When("Clicking on a link under Health and Safety")
public void clicking_on_a_link_under_Health_and_Safety() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@When("Select an item")
public void select_an_item() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@When("Capture the price of the selected item")
public void capture_the_price_of_the_selected_item() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@When("Goto the cart and view the cart")
public void goto_the_cart_and_view_he_cart() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}
	
}
